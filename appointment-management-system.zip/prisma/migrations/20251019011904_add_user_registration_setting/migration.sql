-- AlterTable
ALTER TABLE "OrganizationConfig" ADD COLUMN     "allowUserRegistration" BOOLEAN NOT NULL DEFAULT true;
