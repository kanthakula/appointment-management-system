-- AlterTable
ALTER TABLE "Timeslot" ADD COLUMN     "archived" BOOLEAN NOT NULL DEFAULT false;
