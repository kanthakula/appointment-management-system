-- AlterTable
ALTER TABLE "Registration" ADD COLUMN     "actualCheckInCount" INTEGER;
